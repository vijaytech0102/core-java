package hospital;

interface Billable {
    double generateBill();
}
