package multilevel;

public class Department extends Employee {
	
	int department_id;
	String department_name;
	
	
	public Department() {
		super();
	}


	public Department(int department_id, String department_name, int eid, String e_name, int cid, String cname) {
		super(eid, e_name, cid, cname);
		this.department_id = department_id;
		this.department_name = department_name;
	}
	
	
	public Department(int department_id, String department_name) {
		super();
		this.department_id = department_id;
		this.department_name = department_name;
	}


	public void display_department()
	{
		super.display_company();
		super.display_employee();
		System.out.println(department_id);
		System.out.println(department_name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Company cobj= new Company(11, "Oracle");
		Department dobj= new Department(101,"Computer Science");
//		dobj.display_department();
		Department obj= new Department(101,"Computer Science",1,"Karan", 1001,"Oracle");
		obj.display_department();
		
	}

}
