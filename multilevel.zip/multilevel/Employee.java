package multilevel;

public class Employee extends Company {
	
	int emp_id;
	String emp_name;
	
	
	
	public Employee() {
		super();
	}
	
	
	 public Employee(int emp_id, String emp_name,int cid, String cname) {
		super(cid, cname);
		this.emp_id = emp_id;
		this.emp_name = emp_name;
	}
	public void display_employee()
	 {
		 System.out.println(emp_id);
		 System.out.println(emp_name);
	 }
	
	
}
