package multilevel;

public class Company {
	int company_id;
	String company_Name;
	
	
	public Company() {
		super();
	}


	public Company(int company_id, String company_Name) {
		super();
		this.company_id = company_id;
		this.company_Name = company_Name;
	}
	
	public void display_company()
	{
		System.out.println(company_id);
		System.out.println(company_Name);
	}
	
}
