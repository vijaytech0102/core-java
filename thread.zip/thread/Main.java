package thread;

public class Main {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Display d1=new Display();
		Display d2=new Display();
		System.out.println(d1==d2);
		System.out.println(d1.hashCode());
		System.out.println(d2.hashCode());
		
	}

}
