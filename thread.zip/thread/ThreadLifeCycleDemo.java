package thread;

class MyThread extends Thread {
    public void run() {
        
    	System.out.println(getName() + " is RUNNING");
        try {
            Thread.sleep(100000); // TIMED_WAITING
        } catch (InterruptedException e) {
        	
        }
        System.out.println(getName() + " finished");
    }
}
 
public class ThreadLifeCycleDemo {
    public static void main(String[] args) throws InterruptedException {
        MyThread t = new MyThread();
        System.out.println("State after creation: " + t.getState()); // NEW
 
        t.start();
        System.out.println("State after start(): " + t.getState()); // RUNNABLE
 
        Thread.sleep(10000); 
        System.out.println("State while running: " + t.getState()); // RUNNING or TIMED_WAITING (if in sleep)
 
        t.join(); // wait for thread to finish
        System.out.println("State after completion: " + t.getState()); // TERMINATED
    }
}
 