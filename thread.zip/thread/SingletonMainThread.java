package thread;

public class SingletonMainThread {
    public static void main(String[] args) {
        // Simulate multiple threads trying to access Singleton
        Runnable task = () -> {
            Singleton singleton = Singleton.getInstance();
            singleton.showMessage();
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        t1.start();
        t2.start();
    }
}
