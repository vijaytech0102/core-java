package thread;

class Printer {
    // Synchronized method to ensure only one thread prints at a time
     synchronized void printDocument(String documentName) {
        System.out.println(Thread.currentThread().getName() + " is printing: " + documentName);
        for (int i = 1; i <= 3; i++) {
            System.out.println(documentName + " - Page " + i);
            try {
                Thread.sleep(100); // Simulate printing delay
            } catch (InterruptedException e) {
                System.out.println("Printing interrupted.");
            }
        }
        System.out.println(Thread.currentThread().getName() + " finished printing: " + documentName);
    }
}

class PrintJob extends Thread {
    Printer printer;
    String document;

    PrintJob(Printer printer, String document) {
        this.printer = printer;
        this.document = document;
    }

    public void run() {
        printer.printDocument(document);
    }
}

public class PrinterSyncDemo {
    public static void main(String[] args) {
        Printer sharedPrinter = new Printer();

        PrintJob job1 = new PrintJob(sharedPrinter, "Resume.pdf");// thread 0
        PrintJob job2 = new PrintJob(sharedPrinter, "Report.docx"); // thread 1
        PrintJob job3 = new PrintJob(sharedPrinter, "Invoice.xlsx"); // thread 2

        job2.start();
        job1.start();
        job3.start();
    }
}
