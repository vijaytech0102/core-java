package thread;

public class Display {

	public Display() {
		super();
		System.out.println("Constructor calling");
	}
	
	public void print()
	{
		System.out.println("Hello");
	}
	
	public void output()
	{
		System.out.println("Hello");
	}
}
