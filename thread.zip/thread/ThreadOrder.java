package thread;

class ThreadOrder1 extends Thread {
	synchronized public void run()			
     {  			
          for(int i=1;i<=5;i++)			
          {    			
             System.out.println(Thread.currentThread().getName()+"-"+ i);			
//             //System.out.println(i);			
//             //Thread.currentThread().getName()	
        	  System.out.println("Hii"+i);
        	  try {
  				Thread.sleep(10);
  			} catch (InterruptedException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
          }  			
		
		
      }  			

}

class ThreadOrder2 extends Thread {
	synchronized public void run()			
    {  			
         for(int i=1;i<=5;i++)			
         {    			
            System.out.println(Thread.currentThread().getName()+"*"+ i);			
//            //System.out.println(i);			
//            //Thread.currentThread().getName()
        	 System.out.println("Hello"+i);
        	 try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
         }  			
		
		
     }  			

}

public class ThreadOrder{
	public static void main(String[] args)
	{
		ThreadOrder1 obj1= new ThreadOrder1();
		ThreadOrder2 obj2= new ThreadOrder2();
		obj1.start();
		obj2.start();
	}
}
