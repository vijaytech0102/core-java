package thread;

class RunnableExample implements Runnable					
{					
			public void run()		
			{		
		         System.out.println("Thread is running...");			
					
			}		
					
		    public static void main(String args[])			
		    {			
		         			
			     RunnableExample  obj=  new RunnableExample();		
			     Thread t1= new Thread(obj); //Thread creation		
			     System.out.println("State after start(): " + t1.getState()); //
			     t1.start(); // Thread Runable	
			     System.out.println("Main Thread is running...");		
	   }			
					
}					
