package thread;

public class SingletonThread {
    private static SingletonThread instance;
    

    // Private constructor
    private SingletonThread() {
        System.out.println("Singleton instance created.");
    }

    // Synchronized method to control simultaneous access
    public static synchronized SingletonThread getInstance() {
        if (instance == null) {
            instance = new SingletonThread();
            
        }
        return instance;
    }

    public void showMessage() {
        System.out.println("Hello from Singleton!");
    }
}
