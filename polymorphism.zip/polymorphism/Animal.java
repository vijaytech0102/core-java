package polymorphism;

public class Animal {
	String name;
	String color;
	
	public void sound()
	{
		System.out.println("Hello";)
	}
	
}
