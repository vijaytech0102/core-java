package polymorphism;

import hierarchical.Student;

public class CompileTime {
	
	//method overloading
	// Rules for overloading
	// return type same doesn't matter
	// parameter different
	// 1. parameter 2. data type --> return type
	public int add(int a, int b)
	{
		return a+b;
	}
	public double add(double a, double b)
	{
		return a+b;
	}
	public String add(String s1, String s2)
	{
		return s1+s2;
	}
	public static void main(String[] args) {
		
		CompileTime obj= new CompileTime();
		 int d=obj.add(1, 2);
		 String Res=obj.add("Hello", "Java");
		 System.out.println(d+Res);
		
				
	}

}
