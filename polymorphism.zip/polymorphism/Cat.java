package polymorphism;

public class Cat extends Animal {
	
	String name;
	String color;
	
	public void sound()
	{
		System.out.println("Meowwww");
	}
	
	public static void main(String[] args) {
	 Animal a; // reference parent 
	 a= new Cat(); // child-->> upcasting // Dynamic polymorphism
	 a.sound();
	}
	
}
