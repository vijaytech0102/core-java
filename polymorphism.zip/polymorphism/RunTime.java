package polymorphism;

public class RunTime {
		// method overriding
		// object initialization at run-time
		// Parent child relationship--> Inheritance
		// Is- A relationship
		// Upcasting--> dynamic binding-->dynamic polymorphism
	
}
