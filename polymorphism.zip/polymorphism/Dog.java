package polymorphism;

public class Dog extends Animal {

	String name;
	String color;
	
	public void sound()
	{
		System.out.println("Barkingg...");
	}
	
}
