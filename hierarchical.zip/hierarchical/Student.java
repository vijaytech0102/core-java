package hierarchical;

public class Student extends University {
	
	int s_id;
	String s_name;
	
	
	
	public Student() {
		super();
		System.out.println("Student constructor is called");
	}

	public Student(int s_id, String s_name) {
		super();
		this.s_id = s_id;
		this.s_name = s_name;
	}
	
	public Student(int s_id, String s_name, int u_id, String u_name) {
		super(u_id, u_name);
		this.s_id = s_id;
		this.s_name = s_name;
		
	}
	public void display_student()
	{
		super.display_university();
		System.out.println("Student_Id:"+s_id);
		System.out.println("Studnet name:"+s_id);
	}
	public static void main(String[] args) {
		Student s= new Student(101, "Ajay", 10, "DU");
		s.display_student();
		Student s1= new Student();
	}

}
