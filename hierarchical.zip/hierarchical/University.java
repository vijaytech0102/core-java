package hierarchical;

public class University {
	
	int uni_id;
	String uni_name;
	
	
	
	public University() {
		super();
		System.out.println("University constructor is called");
	}

	public University(int uni_id, String uni_name) {
		super();
		this.uni_id = uni_id;
		this.uni_name = uni_name;
	}

	public void marksheet()
	{
		System.out.println("Marksheet is generated");	
	}
	public void display_university()
	{
		System.out.println("Univeristy Id:"+uni_id);
		System.out.println("Univeristy Name:"+uni_name);
	}
	
}
