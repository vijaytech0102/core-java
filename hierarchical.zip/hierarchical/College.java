package hierarchical;

public class College extends University {

		int college_id;
		String college_name;
		
		public College(int college_id, String college_name) {
			super();
			this.college_id = college_id;
			this.college_name = college_name;
		}
		
		public void college_display()
		{
			super.display_university();
			System.out.println("College Id:"+college_id);
			System.out.println("College Name:"+ college_name);
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}
		
}
