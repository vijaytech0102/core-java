package thread;

class SharedResource {
    private String message;
    private boolean hasMessage = false;

    public synchronized void produce(String msg) {
        while (hasMessage) {
            try {
                wait(); // Wait until the message is consumed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        message = msg;
        hasMessage = true;
        System.out.println("Produced: " + message);
        notify(); // Notify the consumer
    }

    public synchronized void consume() {
        while (!hasMessage) {
            try {
                wait(); // Wait until a message is produced
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Consumed: " + message);
        hasMessage = false;
        notify(); // Notify the producer
    }
}

public class WaitNotifyExample {
    public static void main(String[] args) {
        SharedResource resource = new SharedResource();

        Thread producer = new Thread(() -> {
            String[] messages = {"Hello", "World", "From", "Producer"};
            for (String msg : messages) {
                resource.produce(msg);
                try {
                    Thread.sleep(1000); // Simulate time to produce
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        Thread consumer = new Thread(() -> {
            for (int i = 0; i < 4; i++) {
                resource.consume();
                try {
                    Thread.sleep(1500); // Simulate time to consume
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        producer.start();
        consumer.start();
    }
}
