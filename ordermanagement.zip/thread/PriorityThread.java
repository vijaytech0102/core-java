package thread;

class PriorityThread extends Thread {
    synchronized public void run() {
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println(Thread.currentThread().getName() + " with priority " +
                Thread.currentThread().getPriority() + " is running.");
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public static void main(String[] args) throws InterruptedException {
        PriorityThread t1 = new PriorityThread();
        PriorityThread t2 = new PriorityThread();
        PriorityThread t3 = new PriorityThread();
        PriorityThread t4 = new PriorityThread();
        PriorityThread t5 = new PriorityThread();
        PriorityThread t6 = new PriorityThread();

        t1.setName("t1");
        t2.setName("t2");
        t3.setName("t3");
        t4.setName("t4");
        t5.setName("T5");
        t6.setName("T6");
        
        t1.setPriority(Thread.MIN_PRIORITY);   // Priority 1
        t2.setPriority(Thread.NORM_PRIORITY);  // Priority 5 (default)
        t3.setPriority(Thread.MAX_PRIORITY);   // Priority 10
        t4.setPriority(4);
        t5.setPriority(7);
        t6.setPriority(6);
        
        t1.start();
        t2.start();
        t2.join();
        t3.start();
        t4.start();
        t4.join();
        t5.start();
        t6.start();
    }
}
