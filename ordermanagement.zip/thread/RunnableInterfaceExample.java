package thread;

class MyThread1 implements Runnable {					
	public void run() {					
		System.out.println("Thread 1 is running");				
	}					
}					
					
class MyThread2 implements Runnable {					
	public void run() {					
		System.out.println("Thread 2 is running");				
	}
}					
					
class MyThread3 implements Runnable {					
	public void run() {					
	
	System.out.println("Thread 3 is running");	
	}
}					
					
class MyThread4 implements Runnable {					
	public void run() {					
		System.out.println("Thread 1 is running");
	}
					
}					
					
class RunnableInterfaceExample {					
	public static void main(String args[]) {					
		MyThread1 obj1 = new MyThread1();					
		MyThread2 obj2 = new MyThread2();					
		MyThread3 obj3 = new MyThread3();					
		MyThread4 obj4 = new MyThread4();					
					
		Thread t1 = new Thread(obj1);					
		Thread t2 = new Thread(obj2);					
		Thread t3 = new Thread(obj3);					
		Thread t4 = new Thread(obj4);					
					
		t1.start();					
		t2.start();					
		t3.start();					
		t4.start();
		System.out.println("Thread 1 is running");	
	}
	}					
