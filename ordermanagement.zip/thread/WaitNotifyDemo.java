package thread;

class Store {
	private int item = 0;
	// Consumer - waits if no item
	public synchronized void consume() throws InterruptedException {
		while (item == 0) {
			System.out.println("No item to consume, waiting...");
			wait(); // releases lock and waits
		}	
		
		item--;
		System.out.println("Consumed 1 item. Items left: " + item);
		notify(); // wake up producer if waiting
	}
	// Producer - waits if item is already present
	public synchronized void produce() throws InterruptedException {
		while (item == 1) {
			System.out.println("Item already produced, waiting...");
			wait(); // releases lock and waits
		}
		item++;
		System.out.println("Produced 1 item. Items available: " + item);
		notify(); // wake up consumer if waiting
	}
}

class Producer extends Thread {
	private Store store;
	public Producer(Store store) {
		this.store = store;
	}
	public void run() {
		try {
			for (int i = 0; i < 5; i++) {
				store.produce();
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {}
	}
}

class Consumer extends Thread {
	private Store store;
	public Consumer(Store store) {
		this.store = store;
	}
	public void run() {
		try {
			for (int i = 0; i < 5; i++) {
				store.consume();
				Thread.sleep(1500);
			}
		} catch (InterruptedException e) {}
	}
}

public class WaitNotifyDemo {
	public static void main(String[] args) {
		Store store = new Store();
		Producer producer = new Producer(store);
		Consumer consumer = new Consumer(store);
		consumer.start();
		producer.start();
	}
}