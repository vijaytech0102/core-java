package thread;

class ThreadExample extends Thread			
{  			
     public void run()			
     {  			
          for(int i=1;i<=5;i++)			
          {    			
             System.out.println(Thread.currentThread().getName()+"-"+ i);			
             //System.out.println(i);			
             //Thread.currentThread().getName()			
          }  			
		
		
      }  			
  			
   public static void main(String args[])			
   {  			
       ThreadExample t1=new ThreadExample();  //Thread 0			
       ThreadExample t2=new ThreadExample();  //Thread 1			
       ThreadExample t3=new ThreadExample();  //Thread 2			
       ThreadExample t4=new ThreadExample();  ////Thread 3			
       ThreadExample t5=new ThreadExample();  ////Thread 4			
        t1.start();  			
        t2.start();  			
        t3.start(); 			
        t4.start(); 			
        t5.start(); 			
			
   }  			
}  			
