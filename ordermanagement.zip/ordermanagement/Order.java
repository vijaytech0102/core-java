package ordermanagement;

public class Order {
    private String status = "PLACED";

    public synchronized void waitForStatus(String expectedStatus) {
        while (!status.equals(expectedStatus)) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void updateStatus(String newStatus) {
        status = newStatus;
        System.out.println("Order status updated to: " + status);
        notifyAll();
    }

    public String getStatus() {
        return status;
    }
}
