package ordermanagement;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Order order = new Order();

        OrderStage packer = new OrderStage(order, "PLACED", "PACKED");
        OrderStage shipper = new OrderStage(order, "PACKED", "SHIPPED");
        OrderStage deliverer = new OrderStage(order, "SHIPPED", "DELIVERED");

        packer.setName("Packer");
        shipper.setName("Shipper");
        deliverer.setName("Deliverer");

        packer.setPriority(Thread.NORM_PRIORITY + 1);
        shipper.setPriority(Thread.NORM_PRIORITY);
        deliverer.setPriority(Thread.NORM_PRIORITY - 1);

        packer.start();
        shipper.start();
        deliverer.start();

        packer.join();
        shipper.join();
        deliverer.join();

        System.out.println("Order processing complete. Final status: " + order.getStatus());
    }
}
