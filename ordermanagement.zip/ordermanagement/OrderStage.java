package ordermanagement;

public class OrderStage extends Thread {
    private final Order order;
    private final String currentStatus;
    private final String nextStatus;

    public OrderStage(Order order, String currentStatus, String nextStatus) {
        this.order = order;
        this.currentStatus = currentStatus;
        this.nextStatus = nextStatus;
    }

    @Override
    public void run() {
        order.waitForStatus(currentStatus);
        try {
            Thread.sleep(2000); // Simulate processing time
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        order.updateStatus(nextStatus);
    }
}
