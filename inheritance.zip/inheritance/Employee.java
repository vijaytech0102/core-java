package inheritance;

public class Employee {
	int  id;
	String name;
	public Employee() {
		super();
	}
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public void display()
	{
		System.out.println(id);
		System.out.println(name);
	}
	
}
