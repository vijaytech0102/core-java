package inheritance;

public class Department extends Employee  {

	int dept_id;
	String Dept_name;
	
	
	public Department() {
		super();
	}
	

	public Department(int dept_id, String dept_name) {
		super();
		this.dept_id = dept_id;
		Dept_name = dept_name;
	}
	

	public Department(String dept_name) {
		super();
		Dept_name = dept_name;
	}
	
	public Department(int dept_id, String dept_name, int id, String name) {
		super(id,name);
		this.dept_id = dept_id;
		Dept_name = dept_name;
	}
	
	public void display_department()
	{
		super.display();
		System.out.println(dept_id);
		System.out.println(Dept_name);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee();
		Employee emp1 = new Employee(1,"Rahul");
		
		emp1.display();
		
		Department dep1= new Department(101, " Computer Science", 102,"Karan");
		dep1.display_department();
	}

}
